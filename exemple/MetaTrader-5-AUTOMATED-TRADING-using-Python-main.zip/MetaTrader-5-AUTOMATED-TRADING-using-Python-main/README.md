# MetaTrader-5-AUTOMATED-TRADING-using-Python

🇬🇧 https://www.udemy.com/course/metatrader-5-automated-trading-using-python-tutorial/?referralCode=9E20B45913B197DAE507


<br>
🇫🇷 Arrive bientôt

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw

<br>

### VPS / Install Windows in your mac

VPS: https://bit.ly/3IGHG8x

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://bit.ly/36St1Ka
