# Algorithmic-Trading-with-Python-Machine-Learning-strategies

🇬🇧 https://www.udemy.com/course/python-for-algorithmic-trading-machine-learning-strategies/?referralCode=26FA91C90EE08F479C00 


<br>
🇫🇷 https://www.udemy.com/course/trading-algorithmique-avec-python-machine-learning/?referralCode=82E6B87905A4B863221A

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw

<br>

### VPS / Install Windows in your mac

VPS: https://billing.virmach.com/aff.php?aff=10381

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://www.parallels.com/fr/
