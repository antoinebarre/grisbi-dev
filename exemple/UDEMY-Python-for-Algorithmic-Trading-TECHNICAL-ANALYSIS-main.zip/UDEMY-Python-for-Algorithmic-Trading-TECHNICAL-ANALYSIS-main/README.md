# Python for Finance and Algorithmic Trading
🇬🇧 https://www.udemy.com/course/python-for-algorithmic-trading-technical-indicators/?couponCode=57145EC3845DB1E4D6EA 


<br>
🇫🇷 https://www.udemy.com/course/trading-algorithmique-avec-python-analyse-technique/?referralCode=21E302A2618B8356B244

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw



### VPS / Install Windows in your mac

VPS: https://billing.virmach.com/aff.php?aff=10381

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://www.parallels.com/fr/
