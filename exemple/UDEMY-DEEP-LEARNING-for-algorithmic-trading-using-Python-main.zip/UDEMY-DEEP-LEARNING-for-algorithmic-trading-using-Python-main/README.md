# Deep-learning-for-algorithmic-trading-using-Python

🇬🇧 


<br>
🇫🇷 

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw

<br>

### VPS / Install Windows in your mac

VPS: https://billing.virmach.com/aff.php?aff=10381

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://www.parallels.com/fr/
