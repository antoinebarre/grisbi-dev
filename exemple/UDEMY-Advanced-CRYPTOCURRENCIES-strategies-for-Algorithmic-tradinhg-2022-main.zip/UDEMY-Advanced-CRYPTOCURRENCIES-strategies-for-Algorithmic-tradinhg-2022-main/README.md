# Advanced-crypto-strategies-for-Algorithmic-tradinhg-2022

🇬🇧 https://www.udemy.com/course/advanced-crypto-strategies-for-algorithmic-trading-2022/?referralCode=B6F3F85994FDAB997296


<br>
🇫🇷 https://www.udemy.com/course/strategies-crypto-pour-le-trading-algorithmique-2022/?referralCode=103FDF031D59A06DE775

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw

<br>

### VPS / Install Windows in your mac

VPS: https://billing.virmach.com/aff.php?aff=10381

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://www.parallels.com/fr/
