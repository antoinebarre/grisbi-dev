# Algorithmic-trading-using-PRICE-ACTION-strategies

🇬🇧 https://www.udemy.com/course/algorithmic-trading-using-price-action-strategies/?referralCode=C71F2D33571DDD9C48E4


<br>
🇫🇷 AVAILABLE SOON

<br>
<br>

### Ressources

💰 Join our community: https://discord.gg/wXjNPAc5BH

📚Read our book: https://www.amazon.com/gp/product/B09HG18CYL 

🖥️Quantreo's YouTube channel: https://www.youtube.com/channel/UCp7jckfiEglNf_Gj62VR0pw



### VPS / Install Windows in your mac

VPS: https://billing.virmach.com/aff.php?aff=10381

BOOT CAMP MAC: https://www.youtube.com/watch?v=Hmm9Q-T0oTo

Parrallels Desktop: https://www.parallels.com/fr/
